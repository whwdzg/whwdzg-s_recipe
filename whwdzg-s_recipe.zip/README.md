<div align="center">
    <img align="center" src="https://raw.githubusercontent.com/whwdzg/whwdzg-s_recipe/main/pack.png" alt="logo" width="200">
    <h1 align="center">whwdzg's_recipe</h1>
    <p align="enter">Add some recipes to Minecraft</p>
    <img alt="GitHub Repo stars" src="https://img.shields.io/github/stars/whwdzg/whwdzg-s_recipe">
    <img alt="GitHub forks" src="https://img.shields.io/github/forks/whwdzg/whwdzg-s_recipe">
    <img alt="GitHub last commit" src="https://img.shields.io/github/last-commit/whwdzg/whwdzg-s_recipe">
    <img alt="GitHub contributors" src="https://img.shields.io/github/contributors/whwdzg/whwdzg-s_recipe">
    <img alt="GitHub (Pre-)Release Date" src="https://img.shields.io/github/release-date-pre/whwdzg/whwdzg-s_recipe">
    <img alt="GitHub release (with filter)" src="https://img.shields.io/github/v/release/whwdzg/whwdzg-s_recipe">
    <img alt="GitHub tag (with filter)" src="https://img.shields.io/github/v/tag/whwdzg/whwdzg-s_recipe">
    </br>
</div>

# Modrinth
[https://modrinth.com/datapack/whwdzg-s-recipe](https://modrinth.com/datapack/whwdzg-s-recipe)

# Q&A
- **1.How to get the recipe?**

  After you install the datapack/mod, type: /function whw_recipe:recipe

- **2.Where can I check out the recipes that are included in whwdzg's recipe?**

  In Github Wiki of the whwdzg/whwdzg-s_recipe repo
**(Not Finished Yet)**.
  
  You can check out the craft recipes in the recipe book of the craft table.I suggest to install Just Enough Items to check out the rest recipes.